const fs = require('fs');
const path = require('path');

const dir = __dirname;

// Регулярки
const scriptTagRegex = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi;
const iframeTagRegex = /<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi;
const jsLinkRegex = /<link\b[^>]*as=["']?script["']?[^>]*>/gi;

fs.readdirSync(dir).forEach(file => {
  if (path.extname(file) === '.html') {
    const filePath = path.join(dir, file);
    let content = fs.readFileSync(filePath, 'utf8');

    // Удаляем <script> и <iframe>
    content = content.replace(scriptTagRegex, '');
    content = content.replace(iframeTagRegex, '');

    // Удаляем только <link> с as="script"
    content = content.replace(jsLinkRegex, '');

    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Очищен: ${file}`);
  }
});
